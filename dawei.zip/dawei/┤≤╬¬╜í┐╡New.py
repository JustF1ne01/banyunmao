# JB群专属版本， 使用愉快！
# 变量名称填: dwjkAccounts (可在下方自定义修改)
# 自定义环境变量名称，一般无需修改默认即可！
bianliang = "dwjkAccounts"
# 变量值填: uid#Authorization (抓包可获取)
# 多号请&隔开，也可以新建变量！
# 本次更新时间: 2024年5月10日
# 9.0.0版本: 实时获取最新活动id-增加统计金额-其他功能优化。
# 本脚本李盛学人生故事，大为健康，仁君贵寿通用脚本。

# 在这里填写激活码，请联系卖家获取激活码！
jhm = "6b62c9f09996b3f0562d8542366f9f8203fd5f769aadbf218123a5fc9ec23a9d"
# 如果不填激活码运行2次后会自动删除脚本！后果自负。


# 全局域名变量如下:
# 请注意，不同的群可能域名不一样，需要修改！
# 点击群里面的故事，点右上角三个点，然后点复制链接。
groupName = "h2.hljdtxt.com"

# 请注意你所在的群里面故事链接是http还是https。
exy = "https"


import time
import random

# 定时规则说明：
# 建议设置每天答1-2题，最大为10题。
# 如果设置10可能会被群主查到，会被移除群聊，加入黑名单！
# ༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒
# 每天答2题-定时规则:
# 0 0 8,10 * * ?
# 以上定时规则为每天8点和10点运行一次，每天到账2个红包。
# ༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒༒
# 如果不怕黑号，不怕被踢出群可以使用以下定时规则:
# 25 05 0-23/1 * * *
# 以上定时规则为每小时自动运行一次，每天到账10个红包。
# 90%的黑号风险，请谨慎使用此定时规则！

# 自定义时间文件名，一般无需修改默认即可！
sjmc = "dwjk"

# 自定义开始运行时的随机延迟时间
time.sleep(random.randint(3, 5)) # 单位秒
# 假如你不想整点运行 可以在上面修改随机时间 增加程序延迟运行

# 自定义上次运行和本次运行的间隔时间：
isj = 2400 # 单位秒（也就是40分钟×60秒=2400秒）
# 时间间隔建议最小设置为40分钟。否则会黑号！


import json
import os
from urllib import parse
import requests
import time
import random
from datetime import datetime
import urllib3
import datetime
import datetime
import hashlib
import uuid
import os
import shutil

host_id = uuid.getnode()
auth_code = hashlib.md5(str(host_id).encode()).hexdigest()
if not os.path.exists('机器码.txt'):
    with open('机器码.txt', 'w') as f:
        f.write(auth_code)
    print(__import__('base64').b64decode("5py65Zmo56CBOg==").decode('utf-8'), auth_code, __import__('base64').b64decode("Cgror7flpI3liLbku6XkuIrmnLrlmajnoIHvvIzogZTns7vljZblrrbojrflj5bmv4DmtLvnoIHjgIIKCuKYheazqOaEj++8muW/hemhu+Whq+WGmea/gOa0u+eggeWQjuaJjeiDvee7p+e7rei/kOihjO+8jOacqua/gOa0u+WGjeasoei/kOihjOS8muiHquWKqOWIoOmZpOaJgOacieiEmuacrOaWh+S7tuWQjuaenOiHqui0n++8gQ==").decode('utf-8'))
    exit()
else:
    activation_code = hashlib.sha256((auth_code + 'osmcc2024').encode()).hexdigest()
    if jhm == activation_code:
        print(__import__('base64').b64decode("5r+A5rS75oiQ5Yqf").decode('utf-8'))
    else:
        print(__import__('base64').b64decode("5r+A5rS756CB6ZSZ6K+v").decode('utf-8'))
        directory = os.path.dirname(os.path.abspath(__file__))
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
        print(__import__('base64').b64decode("6ISa5pys5bey6ZSA5q+B77yB").decode('utf-8'))
        exit()
def get_latest_version():
    response = __import__('requests').get(__import__('base64').b64decode(b'aHR0cDovLzIwMy4xOTUuMjE3LjExMi91cGRhdGUudHh0').decode('utf-8'))
    latest_version = response.text.strip()
    return latest_version
current_version = __import__('base64').b64decode(b'OS4wLjE=').decode('utf-8')
time.sleep(1)
latest_version = get_latest_version()
if current_version != latest_version:
    print(__import__('base64').b64decode("5b2T5YmN54mI5pys5LiN5Y+v55So77yB6K+36IGU57O75Y2W5a625aSE55CG44CC").decode('utf-8'))
    exit()
print(__import__('base64').b64decode("5b2T5YmN54mI5pys5piv5pyA5paw54mI5pys77yM5qyi6L+O5L2/55So77yB").decode('utf-8'))
with open(str(sjmc)+"_time.txt", "r") as file:
    content = file.read()
formatted_content = content.replace("-", ",")
year, month, day, hour, minute, second = map(int, formatted_content.split(","))
set_time = datetime.datetime(year, month, day, hour, minute, second)
current_time = datetime.datetime.now()
if (current_time - set_time).total_seconds() > isj:
    print(__import__('base64').b64decode("6Ze06ZqU5pe26Ze05ruh6Laz6K6+5a6a55qE5pe26Ze044CC44CC44CC").decode('utf-8'))
    current_time = datetime.datetime.now()
    formatted_time = current_time.strftime("%Y-%-m-%-d-%-H-%-M-%-S")
    print(__import__('base64').b64decode("5b2T5YmN6L+Q6KGM5pe26Ze0Og==").decode('utf-8'), formatted_time)
    print("\n")
    with open(str(sjmc)+"_time.txt", "w") as file:
        file.write(formatted_time)
    tz = __import__('requests').get(__import__('base64').b64decode(b'aHR0cDovLzEyNC43MC4xNTQuMjMwL25vdGljZS50eHQ=').decode('utf-8'))
    txt = tz.content.decode('utf-8')
    print(txt)
    print("\n")
    urllib3.disable_warnings()
    def remove_duplicates(arr):
        return list(set(arr))
    def save_array_to_json(array, file_name):
        with open(file_name, "w") as f:
            json.dump(array, f)
    def load_array_from_json(file_name):
        if not os.path.exists(file_name):
            with open(file_name, "w") as f:
                json.dump([], f)
        with open(file_name, "r") as f:
            return json.load(f)
    def count_today_members(datalist):
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        count = 0
        for data in datalist:
            if data["adddate"].startswith(today):
                count += 1
        return count
    def recieveRebBag(uid, Authorization, huodong_id="1648773920"):
        url = f"{exy}://{groupName}/api/index/index"
        headers = {
        "Authorization": Authorization,
        "User-Agent": "/5.0 (Linux; Android 9; NX629J_V1S Build/PQ3A.190705.09211555; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.4472.114 Mobile Safari/537.36 MMWEBID/2157 MicroMessenger/8.0.42.2460(0x28002A54) WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": f"{exy}://{groupName}/",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cookie": "s342b0066=tu7bbcn9brab7rhosb27jomff2",
    }
        data = {"huodong_id": huodong_id, "ids": "", "api_type": "h5", "uid": uid}
        response = requests.post(url, headers=headers, data=data)
        response_content = response.content.decode("utf-8")
        response_data = json.loads(response_content)
        if response_data["code"] == 1:
            wentilist = response_data["wentilist"]
            modified_wentilist = []
            for question in wentilist:
                daan = json.loads(question["daan"])[
                0
            ]
                for option in question["xuanxiang"]:
                    if option["xuhao"] == daan:
                        option["xuanzhong"] = 1
                    else:
                        option["xuanzhong"] = 0
                modified_wentilist.append(question)
            data = json.dumps(modified_wentilist, ensure_ascii=False)
            encoded_data = parse.quote(data)
            a = f"wentilist={encoded_data}&huodong_id={huodong_id}&ids=&api_type=h5&uid={uid}"
            url1 = f"{exy}://{groupName}/api/index/dati"
            response = requests.post(url1, headers=headers, data=a)
            response_data = response.json()
            if "上限" in response.text:
                return True
            if response.json()["code"] == 1:
                print(__import__('base64').b64decode("5o+Q56S677ya6I635b6X546w6YeR").decode('utf-8'), response_data["money"], __import__('base64').b64decode("5YWD").decode('utf-8'))
                return True
            else:
                print(__import__('base64').b64decode("5o+Q56S677ya").decode('utf-8'), response_data["msg"])
                return False
        else:
            if "上限" in response.text:
                return True
            if response_data["code"] == 777:
                print("答题失败，⛔️提示：", response_data["msg"])
                if response_data["prev_huodong_id"]:
                    return recieveRebBag(
                    uid, Authorization, response_data["prev_huodong_id"]
                )
                else:
                    return False
            else:
                print("⛔️提示：", response_data["msg"])
    def getUserTotalNumber(uid, token):
        url = f"{exy}://{groupName}/api/index/index"
        response = requests.post(
            url,
            headers={
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Authorization": token,
            "Connection": "keep-alive",
            "Host": f"{groupName}",
            "Origin": f"{exy}://{groupName}",
            "Referer": f"{exy}://{groupName}/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x6309071d) XWEB/8461 Flue",
            "content-type": "application/x-www-form-urlencoded",
        },
            data={
            "huodong_id": "1648345948",
            "store_id": "131",
            "noneedlogin": "0",
            "api_type": "h5",
            "uid": uid,
        },
            verify=False,
    )
        result = response.json()
        if result["code"] == 1:
            print(f"🧧提示：已领红包总数：{result['user']['count_money_num']}个")
            return int(result["user"]["count_money_num"])
        else:
            print(
            f"⛔️提示：{response.json()['msg']}，请确认自己是哪个群的，每个群域名不一样！"
        )
            return -1
    def checkRecieveNumber(uid, token):
        url = f"{exy}://{groupName}/api/index/datilog"
        response = requests.post(
            url,
            headers={
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Authorization": token,
            "Connection": "keep-alive",
            "Host": f"{groupName}",
            "Origin": f"{exy}://{groupName}",
            "Referer": f"{exy}://{groupName}/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x6309071d) XWEB/8461 Flue",
            "content-type": "application/x-www-form-urlencoded",
        },
            data={
            "api_type": "h5",
            "uid": uid,
        },
            verify=False,
    )
        result = response.json()
        if result["code"] == 1:
            todayNumber = count_today_members(result["datilist"]) or 0
            print(f"🧧提示：今日已领红包数：{todayNumber}个")
            return int(todayNumber)
        else:
            print(
            f"⛔️提示：{response.json()['msg']}，全局域名和账号不匹配，自己看脚本说明修改下配置即可"
        )
            return -1
    if __name__ == "__main__":
        print(__import__('base64').b64decode("5b2T5YmN54mI5pys77ya").decode('utf-8'), str(current_version), __import__('base64').b64decode("SkLnvqTkuJPlsZ7niYhCeeWkp+mYn+mVvw==").decode('utf-8'))
        accounts_list = os.environ.get(bianliang).split("&")
        num_of_accounts = len(accounts_list)
        print(__import__('base64').b64decode("5o+Q56S677ya6I635Y+W5Yiw").decode('utf-8'),num_of_accounts,__import__('base64').b64decode("5Liq6LSm5Y+3Cg==").decode('utf-8'))
        time.sleep(2)
        for accountToken in accounts_list:
            accountConfig = accountToken.split("#")
            print("-" * 40)
            print(f"\n账号[{accountConfig[0]}]开始执行操作")
            print(__import__('base64').b64decode("5o+Q56S677ya5q2j5Zyo6I635Y+W5pyA5paw5rS75YqoSUQ=").decode('utf-8'))
            url = f"{exy}://{groupName}/api/index/huodong"
            headers = {
  'User-Agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.47(0x18002f2c) NetType/WIFI Language/zh_CN",
  'Content-Type': "application/x-www-form-urlencoded",
  'Authorization': accountConfig[1],
  'Sec-Fetch-Site': "same-origin",
  'Accept-Language': "zh-CN,zh-Hans;q=0.9",
  'Sec-Fetch-Mode': "cors",
  'Origin': f"{exy}://{groupName}",
  'Referer': f"{exy}://{groupName}/",
  'Sec-Fetch-Dest': "empty"
    }
            page = 1
            number = 0
            id_values = []
            while page <= 11 and number <= 100:
                payload = f"page={page}&limit=10&keyword=&number={number}&openid=onIRs5pWWYbWED-REneNpBonCnQE&api_type=h5&uid={accountConfig[0]}"
                response = requests.post(url, data=payload, headers=headers)
                data = json.loads(response.text)
                for item in data["list"]:
                    id_value = item["id"]
                    id_values.append(id_value)
                page += 1
                number += 10
            time.sleep(2)
            with open('dwjkid.json', 'w') as file:
                json.dump(id_values, file)
                print(__import__('base64').b64decode("5o+Q56S677ya5pyA5paw5rS75YqoSUTlhpnlhaXmiJDlip8=").decode('utf-8'))
                time.sleep(1)
            activeIdList = remove_duplicates(load_array_from_json("dwjkid.json")) or []
            activeIdList = sorted(activeIdList)
            dqdts = checkRecieveNumber(accountConfig[0], accountConfig[1])
            accountAnswerTime = dqdts + 1
            answerSuccess = 0
            queryNumber = checkRecieveNumber(accountConfig[0], accountConfig[1])
            if queryNumber >= 0:
                answerSuccess = queryNumber
                if answerSuccess == queryNumber + 1:
                    print(f"账号[{accountConfig[0]}]当前题目已答完！")
                    continue
            else:
                print(f"账号[{accountConfig[0]}]获取今日答题数失败！")
                continue
            for activeId in activeIdList:
                if answerSuccess >= accountAnswerTime:
                    print(f"账号[{accountConfig[0]}]当前题目已答完！")
                    break
                if recieveRebBag(accountConfig[0], accountConfig[1], activeId):
                    answerSuccess = answerSuccess + 1
                    print(f"账号[{accountConfig[0]}]延迟3秒后进行下一个账号")
                    time.sleep(random.randint(2, 3))
            print(f"当前账号[{accountConfig[0]}]答题操作 已完成")
            time.sleep(3)
            print(__import__('base64').b64decode("5q2j5Zyo6K6h566X5pS255uK77yM6K+356iN562J5Yeg56eS44CC44CC44CC").decode('utf-8'))
            time.sleep(5)
            url = f"{exy}://{groupName}/api/index/datilog"
            payload = f"api_type=h5&uid={accountConfig[0]}"
            headers = {
    'User-Agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.47(0x18002f2c) NetType/WIFI Language/zh_CN",
    'Content-Type': "text/plain",
    'Authorization': f"{accountConfig[1]}",
    'Sec-Fetch-Site': "same-origin",
    'Accept-Language': "zh-CN,zh-Hans;q=0.9",
    'Sec-Fetch-Mode': "cors",
    'Origin': "https://js.jsdtxt.com",
    'Referer': "https://js.jsdtxt.com/",
    'Sec-Fetch-Dest': "empty"
}
            response = requests.post(url, data=payload, headers=headers)
            data = json.loads(response.text)
            data2 = data.copy()
            for item in data2['datilist']:
                if 'addtime' in item:
                    timestamp = item['addtime']
                    dt = datetime.datetime.fromtimestamp(timestamp)
                    item['addtime'] = dt
            total_hongbao_money = round(sum(float(item.get('hongbao_money', 0)) for item in data2['datilist']), 2)
            now = datetime.datetime.now()
            start_of_day = datetime.datetime(now.year, now.month, now.day)
            end_of_day = start_of_day + datetime.timedelta(days=1)
            start_timestamp = int(start_of_day.timestamp())
            end_timestamp = int(end_of_day.timestamp())
            today_hongbao_money = round(sum(float(item.get('hongbao_money', 0)) for item in data2['datilist'] if 'addtime' in item and start_timestamp <= item['addtime'].timestamp() < end_timestamp), 2)
            print(__import__('base64').b64decode("5b2T5YmN6LSm5Y+357Sv6K6h6I635b6X546w6YeROg==").decode('utf-8'), total_hongbao_money,__import__('base64').b64decode("5YWD").decode('utf-8'))
            print(__import__('base64').b64decode("5b2T5pe26LSm5Y+35LuK5pel6I635b6X546w6YeROg==").decode('utf-8'), today_hongbao_money,__import__('base64').b64decode("5YWD").decode('utf-8'))

else:
    print(__import__('base64').b64decode("5pys5qyh6L+Q6KGM5LiO5LiK5qyh6L+Q6KGM6Ze06ZqU5pe26Ze05bCP5LqO6K6+572u55qE").decode('utf-8'),str(isj),__import__('base64').b64decode("56eSCgrkuLrkuobpmLLmraLotKblj7fpu5HlkI3ljZXvvIznqIvluo/nu5PmnZ/ov5DooYzvvIE=").decode('utf-8'))
    exit()

