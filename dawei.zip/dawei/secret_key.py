# ----激活工具------
# 此位机器码--生成激活码工具
# 使用说明：
# 例如激活码为：957b55c3dab389f7904d6ee42aec0600, 自定义值:osmcc2024，组合
# 自定义值:osmcc2024，在未加密主本中修改。
# 执行生成激活码，填入本的头部，jhm = "" 之中

import hashlib

input_str = '957b55c3dab389f7904d6ee42aec0600osmcc2024'
hashed = hashlib.sha256(input_str.encode()).hexdigest()

print(hashed)